var value1, value2, vax;
let number = document.getElementById("box");
function view(num) {
  number.value += num;
}
function operation(x) {
  value1 = number.value;
  console.log(number.value);
  number.value = "";
  if (x == "+") {
    vax = 0;
  }
  if (x == "-") {
    vax = 1;
  }
  if (x == "*") {
    vax = 2;
  }
  if (x == "/") {
    vax = 3;
  }
}

function result() {
  value2 = number.value;
  if (vax == 0) {
    number.value = Number(value1) + Number(value2);
  }
  if (vax == 1) {
    number.value = Number(value1) - Number(value2);
  }
  if (vax == 2) {
    number.value = Number(value1) * Number(value2);
  }
  if (vax == 3) {
    number.value = Number(value1) / Number(value2);
  }
  // try {
  //   box.value = eval(box.value);
  // }
  // catch (err) {
  //   alert(" Incorrect value");
  // }
}

function allclear() {
  let cl = document.getElementById("box");
  cl.value = "";
}
